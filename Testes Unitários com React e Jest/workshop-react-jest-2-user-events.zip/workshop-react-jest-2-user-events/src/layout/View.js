import React from 'react';

const View = ({children}) => {
    return (
        <div>
            {children}
        </div>
    );
};

export default View;